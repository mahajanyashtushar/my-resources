package PPA;

public class Marvellous
{
    public void fun()
    {
        System.out.println("Inside fun of Marvellous");
    }
}