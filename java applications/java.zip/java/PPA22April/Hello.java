package PPA.LB.DS;

public class Hello
{
    public void run()
    {
        System.out.println("Inside run of Hello");
    }
}