package Marvellous;

public class MIPackage
{
        public void fun()
        {
            System.out.println("Inside fun");
        }
}