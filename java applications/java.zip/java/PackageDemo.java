import Marvellous.MIPackage;

class PackageDemo
{
    public static void main(String arg[])
    {
        MIPackage obj = new MIPackage();
        obj.fun();
    }
}