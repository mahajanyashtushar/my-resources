import java.lang.*;

final class Base
{

}
/*class Derived  extends Base           Not allowed
{

}*/

class Final3
{
    public static void main(String a[])
    {
    }
}