#include<stdio.h>
#define MAX 200

// Enrtry point function
int main()
{
    int no = 10;
    no = no + MAX;

    printf("Jay Ganesh\n");
    printf("Value of no is : %d\n",no);

    return 0;
}