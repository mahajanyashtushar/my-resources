#include<stdio.h>

int main()
{
    int iCnt = 0;       // 1

    while(iCnt < 5)     // 2
    {
        printf("Jay Ganesh\n");     // 4
        //iCnt++;     // 3
    }

    return 0;
}