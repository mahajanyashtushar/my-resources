#include<stdio.h>

int main()
{
    int Data[7];

    printf("Adrress of array is : %u\n",Data);

    printf("Size of array is : %d\n",sizeof(Data));

    return 0;
}








