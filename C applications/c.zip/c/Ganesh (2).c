




#include<stdio.h>       // Header file inclusion
// # Preprocessor directive symbol
// include - Keyword
// stdio.h  Standard input output file

int main()      // Entry point function         Fom where the execution starts
{
    printf("Jay Ganesh...\n");      // USed to print on screen

    return 0;       // MEssage to the operating system
    // 0 indicates the succesfull termination
}

// gcc Ganesh.c -o Myexe
// Myexe
// Output : Jay Ganesh












int no = 11;




double d = 3.1245;




char ch = 'M';













