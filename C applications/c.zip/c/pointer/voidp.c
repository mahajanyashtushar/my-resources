#include<stdio.h>

// #define NULL (void *)0

#define PPA 15000

int main()
{
    int *p = NULL;

    int *q;

    printf("%d",*q);

    return 0;
}


























